package com.atif.myweb.restController.services;

import com.atif.myweb.restController.annotation.Secure;
import org.springframework.stereotype.Service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/test")
@Service
public class Keycloakservice {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getTestString() {
        return "{\"textValue\": \"Not Secure (Without Keycloak)\"}";
    }

    @GET
    @Path("/secure")
    @Secure
    @Produces(MediaType.APPLICATION_JSON)
    public String getTestStringSecured() {
        return "{\"textValue\": \"Secured (With Keycloak)\"}";
    }
}