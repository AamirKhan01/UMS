
package com.atif.myweb.domain.exceptions;

public enum ServiceExceptionType {

    UNAUTHORISED(1000, "You are not authorised for this resource.");

    private final int errorCode;
    private final String errorMessage;

    ServiceExceptionType(int errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
