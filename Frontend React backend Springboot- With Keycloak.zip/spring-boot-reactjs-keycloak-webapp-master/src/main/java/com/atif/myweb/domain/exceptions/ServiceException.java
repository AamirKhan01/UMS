
package com.atif.myweb.domain.exceptions;

public class ServiceException extends RuntimeException {

    private ServiceExceptionType type;

    public ServiceException(ServiceExceptionType type) {
        this.type = type;
    }

    public ServiceExceptionType getType() {
        return type;
    }
}
