
package com.atif.myweb.configuration;

import com.atif.myweb.configuration.DataConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan({"com.atif.myweb"})
@Import(DataConfiguration.class)
public class ApplicationConfiguration {
}
