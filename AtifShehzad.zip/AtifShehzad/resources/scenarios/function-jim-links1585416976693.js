(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_2" : [
        "1e7b53f6-5927-4922-8e1b-93b0a7207752"
      ]
    },
    "466ee12f-b961-4184-80e9-1cc607144b2b" : {
    },
    "3d52e2a8-93e7-47b6-bd0f-5b09215f65e0" : {
      "Button_1" : [
        "09005c35-c68b-482c-8010-6ea655dc3173"
      ]
    },
    "1e7b53f6-5927-4922-8e1b-93b0a7207752" : {
      "Text_1" : [
        "3d52e2a8-93e7-47b6-bd0f-5b09215f65e0"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);