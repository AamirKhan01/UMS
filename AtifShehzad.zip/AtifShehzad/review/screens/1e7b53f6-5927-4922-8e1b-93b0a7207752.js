var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585416976693.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585416976693-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585416976693-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1e7b53f6-5927-4922-8e1b-93b0a7207752" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="MainScreen" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1e7b53f6-5927-4922-8e1b-93b0a7207752-1585416976693.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1e7b53f6-5927-4922-8e1b-93b0a7207752-1585416976693-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1e7b53f6-5927-4922-8e1b-93b0a7207752-1585416976693-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="423" dataY="18"   alt="image">\
          <img src="./images/5d04b958-1b42-4656-89e2-5f6db7130b63.png" />\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="256" dataY="24"   alt="image">\
          <img src="./images/9df5b601-8931-4fed-9cd1-df28b816655d.png" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="77" dataY="18"   alt="image">\
          <img src="./images/80ad0c95-04ce-49fb-8f79-ec9de1e0d0f2.png" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="641" dataY="24"   alt="image">\
          <img src="./images/fb4ee172-cd74-4e96-bbba-a1fadd9d8a2a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="16px" dataX="61" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Student Info</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="16px" dataX="261" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Search Teacher</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="56px" datasizeheight="16px" dataX="445" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">My Portal</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="104px" datasizeheight="16px" dataX="663" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Research Content</span></div></div></div></div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="56" dataY="211"   alt="image">\
          <img src="./images/10ad3304-84c9-4305-a23e-7d45cc5c6066.png" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="256" dataY="211"   alt="image">\
          <img src="./images/122b322a-34e9-4fae-babc-b379b105f08a.png" />\
      </div>\
\
      <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="434" dataY="211"   alt="image">\
          <img src="./images/54bd47c2-fd35-477b-a2e2-2b43c765f74b.png" />\
      </div>\
\
      <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="665" dataY="202"   alt="image">\
          <img src="./images/4aaee910-662d-4af7-98e8-d746fb014aea.png" />\
      </div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="44px" datasizeheight="16px" dataX="61" dataY="320" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Results</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="64px" datasizeheight="16px" dataX="287" dataY="320" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Mentorship</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="116px" datasizeheight="16px" dataX="434" dataY="320" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Syllabus and Books</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="113px" datasizeheight="16px" dataX="671" dataY="320" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Work Relationships</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;