package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.AssignmentsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IAssignmentsRepository extends JpaRepository<AssignmentsEntity, Integer> {
}
