package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.entities.AssignmentsEntity;
import com.example.usermgmt.usermanagement.entities.DeciplinesEntity;
import com.example.usermgmt.usermanagement.entities.DegreeProgramEntity;
import com.example.usermgmt.usermanagement.entities.StudentsEntity;
import com.example.usermgmt.usermanagement.service.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/user")

public class UserController {
    @Autowired
    UserServices userServices;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {return new ResponseEntity<>("The response body", HttpStatus.OK); }
// 1.Get Student Details
    @GetMapping(value = "/details",produces = "application/json")
    public List<StudentsEntity> getAllStudents() {
        return userServices.getStudDetails();
    }

// 2.Get Assignments Details
    @GetMapping(value = "/assignments",produces = "application/json")
    public List<AssignmentsEntity> getAllAssignments() {
        return userServices.getAssignmentsDetails();
    }
// 3.Get Disciplines Details
    @GetMapping(value = "/disciplines",produces = "application/json")
    public List<DeciplinesEntity> getAllPrograms() {
        return userServices.getDisciplinesDetails();
    }
// 3.Get Degree Program Details
    @GetMapping(value = "/programs",produces = "application/json")
    public ResponseEntity<List<DegreeProgramEntity>> getAllDegreePrograms(){
        return new ResponseEntity<>(userServices.getDegreeProgram(), HttpStatus.OK);
    }
//    public List<DegreeProgramEntity> getAllDegreePrograms() {
//        return userServices.getDegreeProgram();
//    }
}
