package com.example.usermgmt.usermanagement.entities;

import javax.persistence.*;
import java.sql.Time;

@Entity
@Table(name = "DEGREE_PROGRAM", schema = "QB")
public class DegreeProgramEntity {
    private long id;
    private String title;
    private Time dateFrom;
    private Time dateTo;
    private String remarks;

    @Id
    @Column(name = "ID")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "TITLE")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "DATE_FROM")
    public Time getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Time dateFrom) {
        this.dateFrom = dateFrom;
    }

    @Basic
    @Column(name = "DATE_TO")
    public Time getDateTo() {
        return dateTo;
    }

    public void setDateTo(Time dateTo) {
        this.dateTo = dateTo;
    }

    @Basic
    @Column(name = "REMARKS")
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DegreeProgramEntity that = (DegreeProgramEntity) o;

        if (id != that.id) return false;
        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        if (dateFrom != null ? !dateFrom.equals(that.dateFrom) : that.dateFrom != null) return false;
        if (dateTo != null ? !dateTo.equals(that.dateTo) : that.dateTo != null) return false;
        if (remarks != null ? !remarks.equals(that.remarks) : that.remarks != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (dateFrom != null ? dateFrom.hashCode() : 0);
        result = 31 * result + (dateTo != null ? dateTo.hashCode() : 0);
        result = 31 * result + (remarks != null ? remarks.hashCode() : 0);
        return result;
    }
}
