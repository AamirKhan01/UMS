package com.example.usermgmt.usermanagement.datatransferobjects;


import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class AuthenticateRequestDTO implements Serializable {
    private String userEmailId;
    private String password;
}
