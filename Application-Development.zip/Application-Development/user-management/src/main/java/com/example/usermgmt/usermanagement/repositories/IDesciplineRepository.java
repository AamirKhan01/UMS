package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.DeciplinesEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IDesciplineRepository extends JpaRepository<DeciplinesEntity, Integer> {
}
