package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.StudentsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.sql.Date;
import java.util.List;

public interface IUsersRepository extends JpaRepository<StudentsEntity, Integer> {

}