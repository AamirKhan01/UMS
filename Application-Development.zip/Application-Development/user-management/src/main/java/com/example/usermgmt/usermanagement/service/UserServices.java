package com.example.usermgmt.usermanagement.service;

import com.example.usermgmt.usermanagement.entities.AssignmentsEntity;
import com.example.usermgmt.usermanagement.entities.DeciplinesEntity;
import com.example.usermgmt.usermanagement.entities.DegreeProgramEntity;
import com.example.usermgmt.usermanagement.entities.StudentsEntity;
import com.example.usermgmt.usermanagement.repositories.IAssignmentsRepository;
import com.example.usermgmt.usermanagement.repositories.IDegreeProgramRepository;
import com.example.usermgmt.usermanagement.repositories.IDesciplineRepository;
import com.example.usermgmt.usermanagement.repositories.IUsersRepository;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServices {

    //private static final org.slf4j.Logger Logger = LoggerFactory.getLogger(UserServices.class);

    @Autowired
    IUsersRepository usersRepository;

    @Autowired
    IAssignmentsRepository iAssignmentsRepository;

    @Autowired
    IDesciplineRepository iDesciplineRepository;

    @Autowired
    IDegreeProgramRepository iDegreeProgramRepository;


//1.Get Student detail
    public List<StudentsEntity>  getStudDetails(){
        List<StudentsEntity> usersEntity = usersRepository.findAll();
        return usersEntity;
    }
// 2.Get Assignments Detail
    public List<AssignmentsEntity>  getAssignmentsDetails(){
        List<AssignmentsEntity> assignments = iAssignmentsRepository.findAll();
        return assignments;
}
// 3.Get Disciplines Detail
    public List<DeciplinesEntity>  getDisciplinesDetails(){
        List<DeciplinesEntity> disciplines = iDesciplineRepository.findAll();
        return disciplines;
}
// 4.Get Degree Program Detail
    public List<DegreeProgramEntity>  getDegreeProgram(){
        //List<DegreeProgramEntity> program = iDegreeProgramRepository.findAll();
        return iDegreeProgramRepository.findAll();
    }
}
