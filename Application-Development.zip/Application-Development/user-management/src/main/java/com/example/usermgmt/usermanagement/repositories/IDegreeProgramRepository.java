package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.DegreeProgramEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IDegreeProgramRepository extends JpaRepository<DegreeProgramEntity,Integer> {
}
