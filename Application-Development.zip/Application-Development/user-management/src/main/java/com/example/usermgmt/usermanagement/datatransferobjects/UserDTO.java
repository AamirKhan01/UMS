package com.example.usermgmt.usermanagement.datatransferobjects;

import lombok.*;

import java.io.Serializable;
import java.sql.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode

public class UserDTO implements Serializable {
    private int id;
    private String userEmailId;
    private String userDisplayName;
    private String password;
    private Date creationDate;
}
