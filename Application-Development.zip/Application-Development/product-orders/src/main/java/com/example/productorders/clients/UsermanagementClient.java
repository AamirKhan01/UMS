package com.example.productorders.clients;

import com.example.productorders.datatransferobjects.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.awt.*;

@FeignClient(value = "USERS")
public interface UsermanagementClient {

    @GetMapping(value = "user/details", produces = MediaType.APPLICATION_JSON_VALUE)
    UserDTO getUserDetails(@RequestParam(required = true) int userId);
}
