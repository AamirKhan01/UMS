package com.example.productorders.repositories;

import com.example.productorders.entities.ProductsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface IProductsRepository extends JpaRepository<ProductsEntity, Integer> {

}
