package com.example.productorders.service;


import com.example.productorders.clients.UsermanagementClient;
import com.example.productorders.datatransferobjects.ProducrtsDto;
import com.example.productorders.datatransferobjects.UserDTO;
import com.example.productorders.datatransferobjects.productUserDTO;
import com.example.productorders.entities.ProductsEntity;
import com.example.productorders.repositories.IProductsRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductsService {
    private static final org.slf4j.Logger Logger = LoggerFactory.getLogger(ProductsService.class);

    @Autowired
    IProductsRepository productsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private UsermanagementClient u;

    public ProducrtsDto addUser(ProducrtsDto userDTO) {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        ProductsEntity productsEntity = productsRepository.saveAndFlush(modelMapper.map(userDTO, ProductsEntity.class));
        return modelMapper.map(productsEntity, ProducrtsDto.class);
    }

    public ProducrtsDto getUserDetails(int userId) {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD).setAmbiguityIgnored(true);
        ProductsEntity productsEntity = productsRepository.findById(userId).get();
        return modelMapper.map(productsEntity, ProducrtsDto.class);
    }

    public ProducrtsDto updateUser(ProducrtsDto userDTO) {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
        ProductsEntity productsEntity = productsRepository.saveAndFlush(modelMapper.map(userDTO, ProductsEntity.class));
        return modelMapper.map(productsEntity, ProducrtsDto.class);
    }

    public Boolean removeUser(int userId) {
        productsRepository.deleteById(userId);
        return Boolean.TRUE;
    }

    public productUserDTO getuserInfo(int userId){
        productUserDTO productUserDTO = new productUserDTO();
        UserDTO userDTO = u.getUserDetails(userId);
        productUserDTO.setUserId(userId);
        productUserDTO.setPurchaserName(userDTO.getUserDisplayName());
        return productUserDTO;
    }

//    public AuthenticateDTO verifyUser(AuthenticateRequestDTO authenticateRequestDTO)
//    {
//        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
//        ProductsEntity usersEntity = IProductsRepository.verifyUser(authenticateRequestDTO.getUserEmailId(),authenticateRequestDTO.getPassword());
//        return modelMapper.map(usersEntity,AuthenticateDTO.class);
//    }
//
//    public List<AuthenticateDTO> searchUsersByCreationDate(Date date)
//    {
//        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD);
//        List<ProductsEntity> listUsersEntity = IProductsRepository.findAllByCreationDate(date);
//        return listUsersEntity.stream().map(users -> modelMapper.map(users,AuthenticateDTO.class)).collect(Collectors.toList());
//    }


}

