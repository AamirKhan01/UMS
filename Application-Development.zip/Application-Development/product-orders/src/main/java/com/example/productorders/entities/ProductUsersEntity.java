package com.example.productorders.entities;

import javax.persistence.*;

@Entity
@Table(name = "product_users", schema = "product-orders", catalog = "")
public class ProductUsersEntity {
    private int productUser;
    private Integer userId;
    private String purchaserName;

    @Id
    @Column(name = "product_user", nullable = false)
    public int getProductUser() {
        return productUser;
    }

    public void setProductUser(int productUser) {
        this.productUser = productUser;
    }

    @Basic
    @Column(name = "user_id", nullable = true)
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "purchaser_name", nullable = true, length = 45)
    public String getPurchaserName() {
        return purchaserName;
    }

    public void setPurchaserName(String purchaserName) {
        this.purchaserName = purchaserName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductUsersEntity that = (ProductUsersEntity) o;

        if (productUser != that.productUser) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        if (purchaserName != null ? !purchaserName.equals(that.purchaserName) : that.purchaserName != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = productUser;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (purchaserName != null ? purchaserName.hashCode() : 0);
        return result;
    }
}
