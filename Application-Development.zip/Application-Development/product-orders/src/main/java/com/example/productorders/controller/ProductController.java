package com.example.productorders.controller;

import com.example.productorders.datatransferobjects.ProducrtsDto;
import com.example.productorders.datatransferobjects.productUserDTO;
import com.example.productorders.service.ProductsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    ProductsService productsService;
    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {
        return new ResponseEntity<>("The response body", HttpStatus.OK);
    }


    @GetMapping(value = "/details", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ProducrtsDto> getProductDetails(@RequestParam(required = true) int prodId) {
        logger.info("Details for product id {} required", prodId);
        return new ResponseEntity<>(productsService.getUserDetails(prodId), HttpStatus.OK);
    }

    ///
    @PostMapping(value = "/add", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ProducrtsDto> addUserDetails(@RequestBody ProducrtsDto ProducrtsDto) {
        logger.info("Adding product Name {}", ProducrtsDto.getProductName());
        return new ResponseEntity<>(productsService.addUser(ProducrtsDto), HttpStatus.OK);
    }

    @PutMapping(value = "/update", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ProducrtsDto> updateUserDetails(@RequestBody ProducrtsDto ProducrtsDto) {
        logger.info("Updating product name {}", ProducrtsDto.getProductName());
        return new ResponseEntity<>(productsService.updateUser(ProducrtsDto), HttpStatus.OK);
    }

    @DeleteMapping(value = "/remove", produces = "application/json")
    public ResponseEntity<Boolean> removeUserDetails(@RequestParam(required = true) int userId) {
        logger.info("Deleting user id {} required", userId);
        return new ResponseEntity<>(productsService.removeUser(userId), HttpStatus.OK);
    }


    @GetMapping(value = "/user-prod-details", produces = "application/json")
    public ResponseEntity<productUserDTO> getUserInfo(@RequestParam(required = true) int userId) {
        logger.info("product details for user", userId);
        return new ResponseEntity<>(productsService.getuserInfo(userId), HttpStatus.OK);
    }



//    @PostMapping(value = "/login",produces = "application/json")
//    public ResponseEntity<AuthenticateDTO> loginUser(@RequestBody AuthenticateRequestDTO authenticateRequestDTO){
//        logger.info("Details for user id {} required", authenticateRequestDTO.getUserEmailId());
//        return new ResponseEntity<>(userServices.verifyUser(authenticateRequestDTO),HttpStatus.OK);
//    }
//    @GetMapping(value = "/data-filter",produces = "application/json")
//    public ResponseEntity<List<AuthenticateDTO>> loginUser(@RequestParam (required = true) Date creationDate){
//        logger.info("User creation on required date {}", creationDate.toString());
//        return new ResponseEntity<>(userServices.searchUsersByCreationDate(creationDate), HttpStatus.OK);
}

///


