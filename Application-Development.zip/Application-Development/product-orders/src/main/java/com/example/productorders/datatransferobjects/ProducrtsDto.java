package com.example.productorders.datatransferobjects;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProducrtsDto {
    private int productId;
    private String productName;
    private String productPurpose;
    private String productDescription;
}
