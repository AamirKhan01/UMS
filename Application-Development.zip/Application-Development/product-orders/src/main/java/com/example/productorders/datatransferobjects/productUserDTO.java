package com.example.productorders.datatransferobjects;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class productUserDTO {

    private int productUser;
    private Integer userId;
    private String purchaserName;
}
