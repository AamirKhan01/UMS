import React from 'react';

export default class Footer extends React.Component {
    render() {
        return (
            <footer>
                <div className="container">
                    <div className="row">
                        <div className="col-md-12" style={{textAlign:"center"}}>
                            <span className="copyright">Copyright &copy; Atif; Shehzed 2020</span>
                        </div>
                    </div>
                </div>
            </footer>
        )
    }
}