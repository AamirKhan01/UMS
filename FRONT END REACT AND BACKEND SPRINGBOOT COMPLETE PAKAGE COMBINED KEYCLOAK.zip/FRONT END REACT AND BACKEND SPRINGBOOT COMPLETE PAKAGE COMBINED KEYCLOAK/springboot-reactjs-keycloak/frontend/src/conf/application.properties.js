export const backendUrl = "/rest";
export const websiteTitle = "Your Title"

