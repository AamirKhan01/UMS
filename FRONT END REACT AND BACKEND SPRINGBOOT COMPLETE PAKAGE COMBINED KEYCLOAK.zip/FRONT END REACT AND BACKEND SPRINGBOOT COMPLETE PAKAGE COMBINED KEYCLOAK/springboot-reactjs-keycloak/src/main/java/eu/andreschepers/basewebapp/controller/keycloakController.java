package eu.andreschepers.basewebapp.controller;

import eu.andreschepers.basewebapp.rest.resource.TestResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/keycloak")
public class keycloakController {

    @Autowired
    TestResource myservice;

    private static final Logger logger = LoggerFactory.getLogger(keycloakController.class);

    @GetMapping(path = "/")
    public String index() {
        return "external";
    }

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {
        return new ResponseEntity<>("The response body", HttpStatus.OK);
    }

    @GetMapping(value = "/nokeycloak", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getUserDetails() {
        logger.info("Details for user id {} required");
        return new ResponseEntity<>(myservice.getTestString(), HttpStatus.OK);
    }

    @GetMapping(value = "/usrdetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getUserDetailsSecured() {
        logger.info("Details for user id {} required");
        return new ResponseEntity<>(myservice.getTestStringSecured(), HttpStatus.OK);
    }

}
