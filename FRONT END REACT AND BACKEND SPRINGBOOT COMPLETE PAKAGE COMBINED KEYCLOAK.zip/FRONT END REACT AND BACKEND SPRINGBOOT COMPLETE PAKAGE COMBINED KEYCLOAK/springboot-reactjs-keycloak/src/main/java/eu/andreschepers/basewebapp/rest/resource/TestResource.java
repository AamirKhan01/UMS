package eu.andreschepers.basewebapp.rest.resource;

import eu.andreschepers.basewebapp.rest.annotation.Secure;
import org.springframework.stereotype.Service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/test")
@Service
public class TestResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getTestString() {
        System.out.println("Iam not asking for keycloak config");
        return "{\"textValue\": \"Test String without implemantation of Keycloak\"}";
    }

    @GET
    @Path("/secure")
    @Secure
    @Produces(MediaType.APPLICATION_JSON)
    public String getTestStringSecured() {
        System.out.println("Iam asking for keycloak config realm Name is atif");
        return "{\"textValue\": \"Test String from secured resource with keyclaok realm\"}";
    }
}