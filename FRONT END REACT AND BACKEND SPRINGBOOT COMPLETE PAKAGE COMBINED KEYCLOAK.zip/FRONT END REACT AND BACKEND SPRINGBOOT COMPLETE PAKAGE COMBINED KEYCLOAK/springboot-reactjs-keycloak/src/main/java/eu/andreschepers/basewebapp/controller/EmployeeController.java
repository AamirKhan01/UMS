package eu.andreschepers.basewebapp.controller;

import eu.andreschepers.basewebapp.entities.EmpUsersEntity;
import eu.andreschepers.basewebapp.services.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
//
//    @Autowired
//    userService employeeService;
//
//    @GetMapping("/response")
//    public ResponseEntity<String> getResponse() {return new ResponseEntity<>("The response body", HttpStatus.OK); }
//    // for Multiple parametric functions....Atif Shehzad
//    @GetMapping(value = "/detailsnew", produces = "application/json")
//    public ResponseEntity <List<EmpUsersEntity>> getuserByPwdanduser(@RequestParam (required = false ) String pwd, String userName) {
//        return new ResponseEntity<>(employeeService.getUsersDetails(pwd, userName), HttpStatus.OK);
//    }
}


