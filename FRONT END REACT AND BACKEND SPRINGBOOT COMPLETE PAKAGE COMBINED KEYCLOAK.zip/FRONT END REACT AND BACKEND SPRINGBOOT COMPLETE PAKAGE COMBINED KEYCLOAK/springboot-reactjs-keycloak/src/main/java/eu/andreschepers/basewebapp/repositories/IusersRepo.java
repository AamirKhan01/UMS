package eu.andreschepers.basewebapp.repositories;


import eu.andreschepers.basewebapp.entities.EmpUsersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IusersRepo    {

  //  List<EmpUsersEntity> findByUserIdAndPassword(String userName, String password);


}
