package eu.andreschepers.basewebapp.services;
import eu.andreschepers.basewebapp.entities.EmpUsersEntity;
import eu.andreschepers.basewebapp.repositories.IusersRepo;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class userService {
    //private static final org.slf4j.Logger Logger = LoggerFactory.getLogger(UserServices.class);
//
//    @Autowired
//    IusersRepo usersRepository;
//
//    public List<EmpUsersEntity> getUsersDetails(String userId, String password){
//        return (List<EmpUsersEntity>) usersRepository.findByUserIdAndPassword(userId,password);
//    }
//
//
//    public List<EmpUsersEntity> getUsersDetailsall(){
//        return (List<EmpUsersEntity>) usersRepository.findAll();
//    }
}
