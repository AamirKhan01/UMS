
package com.atif.myweb.restController.dynamic_feature;
import com.atif.myweb.restController.annotation.Secure;
import org.keycloak.jaxrs.JaxrsBearerTokenFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.container.DynamicFeature;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.FeatureContext;

@Component
public class BearerAuthFeature implements DynamicFeature {

    private JaxrsBearerTokenFilter filter;

    @Autowired
    public BearerAuthFeature(JaxrsBearerTokenFilter filter) {
        this.filter = filter;
    }

    public void configure(ResourceInfo ri, FeatureContext ctx) {
        Secure methodAuth = ri.getResourceMethod().getAnnotation(Secure.class);
        Secure classAuth = ri.getResourceClass().getAnnotation(Secure.class);
        if (methodAuth == null && classAuth == null) return;
        ctx.register(filter);
    }
}