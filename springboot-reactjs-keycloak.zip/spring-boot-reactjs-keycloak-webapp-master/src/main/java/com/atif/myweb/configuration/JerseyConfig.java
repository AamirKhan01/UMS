package com.atif.myweb.configuration;

import com.atif.myweb.restController.ServiceExceptionToResponseMapper;
import com.atif.myweb.restController.dynamic_feature.BearerAuthFeature;
import com.atif.myweb.restController.filter.CORSFilter;
import com.atif.myweb.restController.services.Keycloakservice;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.springframework.stereotype.Component;

import javax.ws.rs.ApplicationPath;

@Component
@ApplicationPath("/rest")
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {
        register(RolesAllowedDynamicFeature.class);
        register(ServiceExceptionToResponseMapper.class);
        register(CORSFilter.class);
        register(BearerAuthFeature.class);
        register(Keycloakservice.class);
    }
}