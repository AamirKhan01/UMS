package com.atif.myweb.restController.pojo;

import com.atif.myweb.domain.exceptions.ServiceException;
import com.atif.myweb.domain.exceptions.ServiceExceptionType;

public class ServiceExceptionResponse {

    private final String error;
    private final int errorCode;
    private final String description;

    public ServiceExceptionResponse(ServiceException ex) {
        ServiceExceptionType type = ex.getType();
        error = type.name();
        errorCode = type.getErrorCode();
        description = type.getErrorMessage();
    }

    public String getError() {
        return error;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getDescription() {
        return description;
    }
}

