
package com.atif.myweb.restController;

import com.atif.myweb.domain.exceptions.ServiceException;
import com.atif.myweb.restController.pojo.ServiceExceptionResponse;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class ServiceExceptionToResponseMapper implements ExceptionMapper<ServiceException> {

    @Override
    public Response toResponse(ServiceException e) {
        return Response.ok()
            .entity(new ServiceExceptionResponse(e))
            .type(MediaType.APPLICATION_JSON)
            .build();
    }
}
