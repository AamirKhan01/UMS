package com.example.usermgmt.usermanagement.entities;

import javax.persistence.*;

@Entity
@Table(name = "user_groups", schema = "user-management", catalog = "")
public class UzmUserGroupsEntity {
    private int id;
    private String groupName;
    private String groupDisplayName;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "group_name", nullable = true, length = 20)
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    @Basic
    @Column(name = "group_display_name", nullable = true, length = 20)
    public String getGroupDisplayName() {
        return groupDisplayName;
    }

    public void setGroupDisplayName(String groupDisplayName) {
        this.groupDisplayName = groupDisplayName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UzmUserGroupsEntity that = (UzmUserGroupsEntity) o;

        if (id != that.id) return false;
        if (groupName != null ? !groupName.equals(that.groupName) : that.groupName != null) return false;
        if (groupDisplayName != null ? !groupDisplayName.equals(that.groupDisplayName) : that.groupDisplayName != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (groupName != null ? groupName.hashCode() : 0);
        result = 31 * result + (groupDisplayName != null ? groupDisplayName.hashCode() : 0);
        return result;
    }
}
