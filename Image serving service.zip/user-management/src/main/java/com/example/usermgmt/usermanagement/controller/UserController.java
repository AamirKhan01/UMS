package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.datatransferobjects.AuthenticateDTO;
import com.example.usermgmt.usermanagement.datatransferobjects.AuthenticateRequestDTO;
import com.example.usermgmt.usermanagement.datatransferobjects.UserDTO;
import com.example.usermgmt.usermanagement.service.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/user")

public class UserController {
    @Autowired
    UserServices userServices;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {return new ResponseEntity<>("The response body", HttpStatus.OK); }

    @GetMapping(value = "/details", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserDTO> getUserDetails(@RequestParam(required = true) int userId) {
        logger.info("Details for user id {} required", userId);
        return new ResponseEntity<>(userServices.getUserDetails(userId), HttpStatus.OK);
    }

    @PostMapping(value = "/add", consumes = "application/json", produces = "application/json")
    public ResponseEntity<UserDTO> addUserDetails(@RequestBody UserDTO userDTO) {
        logger.info("Adding user email address {}", userDTO.getUserEmailId());
        return new ResponseEntity<>(userServices.addUser(userDTO), HttpStatus.OK);
    }

    @PutMapping(value = "/update", consumes = "application/json", produces = "application/json")
    public ResponseEntity<UserDTO> updateUserDetails(@RequestBody UserDTO userDTO) {
        logger.info("Updating user email address {}", userDTO.getUserEmailId());
        return new ResponseEntity<>(userServices.updateUser(userDTO), HttpStatus.OK);
    }

    @DeleteMapping(value = "/remove", produces = "application/json")
    public ResponseEntity<Boolean> removeUserDetails(@RequestParam(required = true) int userId) {
        logger.info("Deleting user id {} required", userId);
        return new ResponseEntity<>(userServices.removeUser(userId), HttpStatus.OK);
    }

    @PostMapping(value = "/login",produces = "application/json")
    public ResponseEntity<AuthenticateDTO> loginUser(@RequestBody AuthenticateRequestDTO authenticateRequestDTO){
        logger.info("Details for user id {} required", authenticateRequestDTO.getUserEmailId());
        return new ResponseEntity<>(userServices.verifyUser(authenticateRequestDTO),HttpStatus.OK);
    }
    @GetMapping(value = "/data-filter",produces = "application/json")
    public ResponseEntity<List<AuthenticateDTO>> loginUser(@RequestParam (required = true) Date creationDate){
        logger.info("User creation on required date {}", creationDate.toString());
        return new ResponseEntity<>(userServices.searchUsersByCreationDate(creationDate), HttpStatus.OK);
    }
}
