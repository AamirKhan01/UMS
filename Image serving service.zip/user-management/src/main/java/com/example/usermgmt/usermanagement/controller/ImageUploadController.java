package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.service.ImageUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class ImageUploadController {

@Autowired
ImageUploadService imageUploadService;

    @PostMapping
    public void uploadImage (@RequestParam("file")MultipartFile file) throws IOException {
        imageUploadService.uploadImage(file);

    }

}



