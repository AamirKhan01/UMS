package com.example.usermgmt.usermanagement.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class ImageUploadService {

    public void uploadImage(MultipartFile file) throws IOException {
// Here is the place where file is to be transferred,
        file.transferTo(new File("C:\\Users\\AYESHA\\Downloads\\"+file.getOriginalFilename()));

    }
}
