var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585660497844.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585660497844-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1585660497844-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7c7179f3-5b86-494d-8aa5-e1decb2d5a31" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Equipment" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7c7179f3-5b86-494d-8aa5-e1decb2d5a31-1585660497844.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/7c7179f3-5b86-494d-8aa5-e1decb2d5a31-1585660497844-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/7c7179f3-5b86-494d-8aa5-e1decb2d5a31-1585660497844-ie8.css" /><![endif]-->\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="1025px" datasizeheight="102px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="384px" datasizeheight="32px" dataX="295" dataY="34" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">University Management System</span></div></div></div></div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="201px" datasizeheight="667px" dataX="-1" dataY="102" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="825px" datasizeheight="62px" dataX="199" dataY="102" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="168px" datasizeheight="24px" dataX="295" dataY="121" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Equipment</span><span id="rtr-s-Text_2_1"> Details</span></div></div></div></div>\
      <div id="s-Personnel" summary="" class="pie datalist firer ie-background commentable non-processed" datamaster="Personnel" datasizewidth="788px" datasizeheight="259px" dataX="220" dataY="183" originalwidth="786px" originalheight="257px"  size="0">\
        <div class="backgroundLayer"></div>\
        <table  >\
          <thead>\
            <tr id="s-Header_1" class="headerrow firer ie-background non-processed">\
              <td class="hidden"></td>\
              <td id="s-Row_cell_1" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="34px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Name</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_3" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="48px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Address</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_5" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">CNIC</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_7" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Starting Date</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_9" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="71px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Ending Date</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_11" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="67px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Department</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_13" class="pie datacell firer non-processed"  datasizewidth="95px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="95px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="23px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">City</span></div></div></div></div>\
\
                </div>\
              </td>\
              <td id="s-Row_cell_15" class="pie datacell firer non-processed"  datasizewidth="121px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="121px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="49px" datasizeheight="16px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">Location</span></div></div></div></div>\
\
                </div>\
              </td>\
            </tr>\
          </thead>\
          <tbody><tr><td></td></tr></tbody>\
        </table>\
      </div>\
      <div id="s-Image_35" class="pie image firer ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="35px" dataX="222" dataY="115"   alt="image" systemName="./images/63601739-44ae-4537-80e0-d6de17ad9466.svg" overlay="#CBCBCB">\
          <?xml version="1.0" encoding="UTF-8"?>\
          <svg preserveAspectRatio=\'none\' width="17px" height="20px" viewBox="0 0 17 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
              <title>user</title>\
              <desc>Created with Sketch.</desc>\
              <g id="s-Image_35-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                  <g id="s-Image_35-user" fill="#666666">\
                      <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1"></path>\
                      <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3"></path>\
                  </g>\
              </g>\
          </svg>\
      </div>\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="29px" dataX="918" dataY="118" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">Add New</span></div></div></div></div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="199px" datasizeheight="102px" dataX="0" dataY="0"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="201px" datasizeheight="33px" dataX="-1" dataY="164" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_11" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="82px" datasizeheight="16px" dataX="7" dataY="173" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">Personnel Info</span></div></div></div></div>\
      <div id="s-Rectangle_5" class="pie rectangle firer commentable non-processed"   datasizewidth="201px" datasizeheight="33px" dataX="-1" dataY="198" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_5_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_12" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="98px" datasizeheight="16px" dataX="7" dataY="205" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">Departments Info</span></div></div></div></div>\
      <div id="s-Rectangle_7" class="pie rectangle firer commentable non-processed"   datasizewidth="201px" datasizeheight="33px" dataX="-1" dataY="232" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_7_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_13" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="86px" datasizeheight="16px" dataX="7" dataY="238" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Equipment Info</span></div></div></div></div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Personnel-template">\
        <![CDATA[\
        <tr id="s-Current_row_1" class="datarow firer ie-background non-processed " align="center">\
          <td class="hidden">\
            <input type="hidden" name="id" value="{{=it.id}}" />\
            <input type="hidden" name="datamaster" value="{{=it.datamaster}}" />\
            <input type="hidden" name="index" value="{{=it.index}}" />\
          </td>\
          <td id="s-Row_cell_2" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_1" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Name" value="{{!it.userdata["Name"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_4" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_2" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Address" value="{{!it.userdata["Address"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_6" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_3" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="CNIC" value="{{!it.userdata["CNIC"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_8" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_4" class="pie date firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="date" name="Starting Date" value="{{!it.userdata["Starting Date"]}}" tabindex="-1" readonly="readonly" /></div></div></div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_10" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_5" class="pie date firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="date" name="Ending Date" value="{{!it.userdata["Ending Date"]}}" tabindex="-1" readonly="readonly" /></div></div></div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_12" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_6" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Department" value="{{!it.userdata["Department"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_14" class="pie datacell firer ie-background non-processed"  datasizewidth="95px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="95px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_7" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="City" value="{{!it.userdata["City"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
          <td id="s-Row_cell_16" class="pie datacell firer ie-background non-processed"  datasizewidth="121px" datasizeheight="37px" dataX="0" dataY="0" originalwidth="121px" originalheight="37px" >\
            <div class="layout scrollable">\
              <div id="s-Input_8" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Location" value="{{!it.userdata["Location"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
            </div>\
          </td>\
        </tr>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;