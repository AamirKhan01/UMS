(function(window, undefined) {

  var jimLinks = {
    "fec97f93-32ca-4b92-9f11-8d6ca6afa55d" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "fec97f93-32ca-4b92-9f11-8d6ca6afa55d"
      ],
      "Button_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    },
    "91942189-4b8c-4200-ad6f-365ab220b4f8" : {
      "Button_1" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Button_2" : [
        "91942189-4b8c-4200-ad6f-365ab220b4f8"
      ],
      "Button_3" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    },
    "7c7179f3-5b86-494d-8aa5-e1decb2d5a31" : {
      "Button_1" : [
        "d6a8359e-8220-479b-a7de-4a780cb758b0"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "fec97f93-32ca-4b92-9f11-8d6ca6afa55d"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    },
    "d6a8359e-8220-479b-a7de-4a780cb758b0" : {
      "Button_1" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ],
      "Button_2" : [
        "fec97f93-32ca-4b92-9f11-8d6ca6afa55d"
      ],
      "Button_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    },
    "414bfaa2-a100-4162-a2ae-b4f46f98b364" : {
      "Button_1" : [
        "91942189-4b8c-4200-ad6f-365ab220b4f8"
      ],
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_12" : [
        "414bfaa2-a100-4162-a2ae-b4f46f98b364"
      ],
      "Text_13" : [
        "7c7179f3-5b86-494d-8aa5-e1decb2d5a31"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);