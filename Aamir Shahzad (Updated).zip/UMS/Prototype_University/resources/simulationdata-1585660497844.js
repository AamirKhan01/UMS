function initData() {
  jimData.datamasters["Personnel"] = [
    {
      "id": 1,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "Personnel",
      "userdata": {
        "Name": "sample text",
        "Address": "sample text",
        "CNIC": "sample text",
        "Starting Date": "09/12/2011",
        "Ending Date": "09/12/2011",
        "Department": "sample text",
        "City": "sample text",
        "Location": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}