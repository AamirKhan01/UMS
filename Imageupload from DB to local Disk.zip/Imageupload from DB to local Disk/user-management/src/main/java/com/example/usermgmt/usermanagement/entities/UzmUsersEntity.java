package com.example.usermgmt.usermanagement.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "users", schema = "user-management")
public class UzmUsersEntity {
    private int id;
    private String userEmailId;
    private String userDisplayName;
    private String password;
    private Date creationDate;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_email_id", nullable = false, length = 45)
    public String getUserEmailId() {
        return userEmailId;
    }

    public void setUserEmailId(String userEmailId) {
        this.userEmailId = userEmailId;
    }

    @Basic
    @Column(name = "user_display_name", nullable = true, length = 45)
    public String getUserDisplayName() {
        return userDisplayName;
    }

    public void setUserDisplayName(String userDisplayName) {
        this.userDisplayName = userDisplayName;
    }

    @Basic
    @Column(name = "password", nullable = true, length = 100)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Basic
    @Column(name = "creation_date", nullable = true)
    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UzmUsersEntity that = (UzmUsersEntity) o;

        if (id != that.id) return false;
        if (userEmailId != null ? !userEmailId.equals(that.userEmailId) : that.userEmailId != null) return false;
        if (userDisplayName != null ? !userDisplayName.equals(that.userDisplayName) : that.userDisplayName != null)
            return false;
        if (password != null ? !password.equals(that.password) : that.password != null) return false;
        if (creationDate != null ? !creationDate.equals(that.creationDate) : that.creationDate != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (userEmailId != null ? userEmailId.hashCode() : 0);
        result = 31 * result + (userDisplayName != null ? userDisplayName.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (creationDate != null ? creationDate.hashCode() : 0);
        return result;
    }
}
