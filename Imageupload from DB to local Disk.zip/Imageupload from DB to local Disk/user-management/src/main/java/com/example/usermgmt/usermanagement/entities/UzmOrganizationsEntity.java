package com.example.usermgmt.usermanagement.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "organizations", schema = "user-management")
public class UzmOrganizationsEntity {
    private int id;
    private String organizationName;
    private String informationEmail;
    private String organizationAddress;
    private Date organizationRegistrationDate;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "organization_name", nullable = true, length = 100)
    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    @Basic
    @Column(name = "information_email", nullable = true, length = 45)
    public String getInformationEmail() {
        return informationEmail;
    }

    public void setInformationEmail(String informationEmail) {
        this.informationEmail = informationEmail;
    }

    @Basic
    @Column(name = "organization_address", nullable = true, length = 1150)
    public String getOrganizationAddress() {
        return organizationAddress;
    }

    public void setOrganizationAddress(String organizationAddress) {
        this.organizationAddress = organizationAddress;
    }

    @Basic
    @Column(name = "organization_registration_date", nullable = true)
    public Date getOrganizationRegistrationDate() {
        return organizationRegistrationDate;
    }

    public void setOrganizationRegistrationDate(Date organizationRegistrationDate) {
        this.organizationRegistrationDate = organizationRegistrationDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UzmOrganizationsEntity that = (UzmOrganizationsEntity) o;

        if (id != that.id) return false;
        if (organizationName != null ? !organizationName.equals(that.organizationName) : that.organizationName != null)
            return false;
        if (informationEmail != null ? !informationEmail.equals(that.informationEmail) : that.informationEmail != null)
            return false;
        if (organizationAddress != null ? !organizationAddress.equals(that.organizationAddress) : that.organizationAddress != null)
            return false;
        if (organizationRegistrationDate != null ? !organizationRegistrationDate.equals(that.organizationRegistrationDate) : that.organizationRegistrationDate != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (organizationName != null ? organizationName.hashCode() : 0);
        result = 31 * result + (informationEmail != null ? informationEmail.hashCode() : 0);
        result = 31 * result + (organizationAddress != null ? organizationAddress.hashCode() : 0);
        result = 31 * result + (organizationRegistrationDate != null ? organizationRegistrationDate.hashCode() : 0);
        return result;
    }
}
