package com.example.usermgmt.usermanagement.repositories;

import java.util.Optional;

import com.example.usermgmt.usermanagement.entities.UsersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ImageRepository extends JpaRepository<UsersEntity, Long> {
    Optional<UsersEntity> findByName(String name);
}