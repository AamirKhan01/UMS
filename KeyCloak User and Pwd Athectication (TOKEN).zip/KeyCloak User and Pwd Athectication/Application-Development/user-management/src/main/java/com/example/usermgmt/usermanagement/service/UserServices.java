package com.example.usermgmt.usermanagement.service;
import com.example.usermgmt.usermanagement.datatransferobjects.UserDTO;
import com.example.usermgmt.usermanagement.entities.EmpUsersEntity;
import com.example.usermgmt.usermanagement.repositories.IUsersRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServices {

    private static final org.slf4j.Logger Logger = LoggerFactory.getLogger(UserServices.class);

    @Autowired
    IUsersRepository usersRepository;

    @Autowired
    private ModelMapper modelMapper;

    public UserDTO getUserDetails(String userId, String password){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STANDARD).setAmbiguityIgnored(true);
        List<EmpUsersEntity> usersEntity = usersRepository.findByUserIdAndPassword(userId,password);
        return modelMapper.map(usersEntity, UserDTO.class);
    }

}
