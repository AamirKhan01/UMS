package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.datatransferobjects.UserDTO;
import com.example.usermgmt.usermanagement.entities.EmpUsersEntity;
import com.example.usermgmt.usermanagement.repositories.IUsersRepository;
import com.example.usermgmt.usermanagement.service.UserServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
@RestController
@RequestMapping("/keycloak")
public class keycloakController {
    @Autowired
    private IUsersRepository iUsersRepository;
    @Autowired
    UserServices userServices;

    private static final Logger logger = LoggerFactory.getLogger(keycloakController.class);

    @GetMapping(path = "/")
    public String index() {
        return "external";
    }

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {return new ResponseEntity<>("The response body", HttpStatus.OK); }

    @GetMapping(value = "/usrdetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserDTO> getUserDetails(@RequestParam(required = true) String userId, String pwd) {
        logger.info("Details for user id {} required", userId,pwd);
        return new ResponseEntity<>(userServices.getUserDetails(userId,pwd), HttpStatus.OK);
    }

    @GetMapping(path = "/users")
    public String customers(Principal principal, Model model) {
        addusers();
        Iterable<EmpUsersEntity> users = iUsersRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("username", principal.getName());
        model.addAttribute("hashcode", principal.hashCode());
        return "users";
    }

    // add customers for demonstration
    public void addusers() {

        EmpUsersEntity user = new EmpUsersEntity();
        user.setUserId("root");
        user.setPassword("atif@123");
//        user.setServiceRendered("Important services");
        iUsersRepository.save(user);
    }
}