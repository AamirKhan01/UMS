package com.example.usermgmt.usermanagement.repositories;

import com.example.usermgmt.usermanagement.entities.EmpUsersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface IUsersRepository extends JpaRepository<EmpUsersEntity, Integer> {

    List<EmpUsersEntity> findByUserIdAndPassword(String userName,String password);


}