package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.datatransferobjects.UserDTO;
import com.example.usermgmt.usermanagement.service.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/user")

public class UserController {
    @Autowired
    UserServices userServices;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/response")
    public ResponseEntity<String> getResponse() {return new ResponseEntity<>("The response body", HttpStatus.OK); }

    @GetMapping(value = "/details", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserDTO> getUserDetails(@RequestParam(required = true) String userId, String pwd) {
        logger.info("Details for user id {} required", userId,pwd);
        return new ResponseEntity<>(userServices.getUserDetails(userId,pwd), HttpStatus.OK);
    }
}
