/*
	Copyright 2018 Andre Schepers

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/
package com.atif.myweb;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootApplication
@RequestMapping
@CrossOrigin(allowCredentials="true")
public class KeyclaokWithReact {
	@GetMapping(path = "/persons")
	public ResponseEntity<List<Persons>> customers(final Principal principal, final Model model) {
		final List personas = new ArrayList<Persons>();
		personas.add(new Persons(1, "test1"));
		personas.add(new Persons(2, "test2"));
		return ResponseEntity.ok(personas);
	}


	public static void main(final String[] args) {
		SpringApplication.run(KeyclaokWithReact.class, args);
	} {
		//SpringApplication.run(KeyclaokWithReact.class, args);
		System.out.println("My Application is UP please run http://localhost:8085/ for welcome page @Atif Shehzad");
	}
	}

