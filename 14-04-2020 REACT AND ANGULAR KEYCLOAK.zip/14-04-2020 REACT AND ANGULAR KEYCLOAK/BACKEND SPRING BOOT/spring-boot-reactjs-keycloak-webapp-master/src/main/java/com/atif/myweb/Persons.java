package com.atif.myweb;

public class Persons {
    private int id;
    private String  number;

    public Persons(final int id, final String num) {
        this.id = id;
        this.number = num;
    }

    public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public String getNombre() {
        return number;
    }

    public void setNombre(final String numbers) {
        this.number = numbers;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final Persons other = (Persons) obj;
        if (id != other.id)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Persons [ID=" + id + ", Number=" + number + "]";
    }
}

