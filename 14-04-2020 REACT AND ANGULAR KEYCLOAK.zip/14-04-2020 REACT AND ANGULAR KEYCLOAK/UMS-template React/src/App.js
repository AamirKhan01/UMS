import React, { Component } from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import Publico from './Publico';
import Protegido from './Protegido';
import './App.css';

// datos muy importantes
// https://scalac.io/user-authentication-keycloak-1/
// https://scalac.io/user-authentication-keycloak-2/d

class App extends Component {

  render() {
    return (

      <BrowserRouter>
        <div>
          <h2 className="abc" >Test page created in UMS Template...</h2>
        </div>

        <div className="container">
          <div className="enlace"><Link to="/" className = "myclass">Un Secured Data click Here</Link></div>
          <div className="enlace"><Link to="/protected"  className = "myclass">Secured with Keycloak Data click Here </Link></div>
          <Route exact path="/" component={Publico} />
          <Route path="/protected" component={Protegido} />
        </div>
      </BrowserRouter>
    );
  }
}
export default App;
