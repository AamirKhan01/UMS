import React, { Component } from 'react';

class Publico extends Component {
  render() {
    return (
      <div>
        <h1 className = "myclass">Non Keycloak</h1>
        <p className = "myclass">This is non Keycloak Content Plz click on Secured content link to redirect to keycloak Authorization</p>
      </div>
    );
  }
}
export default Publico;
