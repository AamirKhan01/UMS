package com.example.usermgmt.usermanagement.controller;

import com.example.usermgmt.usermanagement.entities.UzmUsersEntity;
import com.example.usermgmt.usermanagement.repositories.IUsersRepository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
@RestController
@RequestMapping("/keycloak")
public class keycloakController {


    @Autowired
    private IUsersRepository iUsersRepository;

    @GetMapping(path = "/")
    public String index() {
        return "external";
    }

    @GetMapping(path = "/users")
    public String customers(Principal principal, Model model) {
        addusers();
        Iterable<UzmUsersEntity> users = iUsersRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("username", principal.getName());
        model.addAttribute("hashcode", principal.hashCode());
        return "users";
    }

    // add customers for demonstration
    public void addusers() {

        UzmUsersEntity user = new UzmUsersEntity();
        user.setId(12345);
        user.setPassword("atif@123");
//        user.setServiceRendered("Important services");
        iUsersRepository.save(user);
    }
}